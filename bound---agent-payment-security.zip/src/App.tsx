/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab, AgentNode, MandateItem, TransactionRecord } from './types';
import {
  INITIAL_AGENTS,
  INITIAL_MANDATES,
  INITIAL_TRANSACTIONS,
} from './data/mockData';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { OverviewView } from './views/OverviewView';
import { MandatesView } from './views/MandatesView';
import { PaymentVerificationView } from './views/PaymentVerificationView';
import { AgentsView } from './views/AgentsView';
import { SecurityViolationView } from './views/SecurityViolationView';
import { SecurityAuditView } from './views/SecurityAuditView';
import { ProofModal } from './components/ProofModal';
import { PanicModal } from './components/PanicModal';
import { CreateMandateModal } from './components/CreateMandateModal';
import { RegisterAgentModal } from './components/RegisterAgentModal';
import { EditLimitModal } from './components/EditLimitModal';
import { CommandPaletteModal } from './components/CommandPaletteModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [agents, setAgents] = useState<AgentNode[]>(INITIAL_AGENTS);
  const [mandates, setMandates] = useState<MandateItem[]>(INITIAL_MANDATES);
  const [transactions, setTransactions] = useState<TransactionRecord[]>(INITIAL_TRANSACTIONS);

  // Modals state
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isPanicOpen, setIsPanicOpen] = useState(false);
  const [isCreateMandateOpen, setIsCreateMandateOpen] = useState(false);
  const [isRegisterAgentOpen, setIsRegisterAgentOpen] = useState(false);
  const [proofTarget, setProofTarget] = useState<TransactionRecord | null>(null);
  const [editLimitTarget, setEditLimitTarget] = useState<MandateItem | null>(null);

  // System State
  const [panicSevered, setPanicSevered] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 3500);
  };

  // Keyboard shortcut for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Panic Revoke All Handler
  const handleConfirmPanic = () => {
    setPanicSevered(true);
    setAgents((prev) =>
      prev.map((a) => ({
        ...a,
        status: 'REVOKED',
        heartbeat: 'Severed by Panic protocol',
      }))
    );
    setMandates((prev) =>
      prev.map((m) => ({
        ...m,
        status: 'REVOKED',
        safeBuffer: 'Mandate Inactive (Emergency Protocol)',
      }))
    );
    setIsPanicOpen(false);
    showToast('Panic protocol executed: All agent keys revoked across hardware enclaves.');
  };

  // Add Mandate
  const handleSaveMandate = (newMandate: MandateItem) => {
    setMandates((prev) => [newMandate, ...prev]);
    showToast(`Mandate ${newMandate.code} created & signed with Root Vault KMS.`);
  };

  // Add Agent
  const handleRegisterAgent = (newAgent: AgentNode) => {
    setAgents((prev) => [newAgent, ...prev]);
    showToast(`Agent ${newAgent.name} provisioned in Bound Nitro Enclave.`);
  };

  // Edit Mandate Limit
  const handleSaveLimit = (id: string, newCap: number) => {
    setMandates((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const buffer = newCap - m.spent;
          return {
            ...m,
            cap: newCap,
            safeBuffer: `₹${buffer.toLocaleString()} Safe Buffer Remaining`,
            isThresholdImminent: buffer < 600,
          };
        }
        return m;
      })
    );
    showToast(`Mandate limit updated to ₹${newCap.toLocaleString()}.`);
  };

  // Toggle Mandate Revocation
  const handleToggleRevokeMandate = (id: string) => {
    setMandates((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const nextStatus = m.status === 'ACTIVE' ? 'REVOKED' : 'ACTIVE';
          return {
            ...m,
            status: nextStatus,
            safeBuffer:
              nextStatus === 'ACTIVE'
                ? `₹${(m.cap - m.spent).toLocaleString()} Safe Buffer Remaining`
                : 'Lifecycle Terminated',
          };
        }
        return m;
      })
    );
  };

  // Revoke single agent key
  const handleRevokeAgent = (agentId: string) => {
    setAgents((prev) =>
      prev.map((a) => {
        if (a.id === agentId) {
          const nextStatus = a.status === 'REVOKED' ? 'ACTIVE' : 'REVOKED';
          return {
            ...a,
            status: nextStatus,
            heartbeat: nextStatus === 'ACTIVE' ? 'Restored now' : 'Revoked just now',
          };
        }
        return a;
      })
    );
  };

  // Rotate single agent signature
  const handleRotateSignature = (agentId: string) => {
    const newHash = `sha256:${Math.random().toString(36).substring(2, 7)}…${Math.random().toString(36).substring(2, 5)}`;
    setAgents((prev) =>
      prev.map((a) => {
        if (a.id === agentId) {
          return {
            ...a,
            hash: newHash,
            heartbeat: 'Rotated just now',
          };
        }
        return a;
      })
    );
    showToast(`Cryptographic keypair rotated. Enclave PCR0 attestation re-signed.`);
  };

  // Resolve Policy Violation Action
  const handleResolveViolation = (action: 'override' | 'revoke' | 'reject') => {
    if (action === 'revoke') {
      setAgents((prev) =>
        prev.map((a) =>
          a.id === 'payment-agent'
            ? { ...a, status: 'REVOKED', heartbeat: 'Severed after policy intercept' }
            : a
        )
      );
      showToast('Payment Agent keypair severed. Downstream token invalidation complete.');
    } else if (action === 'override') {
      setTransactions((prev) =>
        prev.map((tx) =>
          tx.id === 'tx_901844'
            ? {
                ...tx,
                decision: 'ALLOW',
                statusLabel: 'OVERRIDDEN',
                verificationType: 'proof',
              }
            : tx
        )
      );
      showToast('One-time WebAuthn biometric override registered.');
    } else {
      showToast('Violation event committed to tamper-proof Merkle audit tree.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8f9ff] text-[#0b1c30]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-[#0b1c30] text-[#ffffff] shadow-2xl border border-[#ffffff]/20 font-mono text-[12px] animate-in slide-in-from-bottom-3">
          <span className="material-symbols-outlined text-[#009668] text-[18px]">
            check_circle
          </span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        panicSevered={panicSevered}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 pt-24 pb-12">
        {/* Navigation Breadcrumb & Quick Switch Bar */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[12px] text-[#76777d]">
            <button
              onClick={() => setActiveTab('overview')}
              className="hover:text-[#0b1c30] cursor-pointer"
            >
              Vault #1
            </button>
            <span>/</span>
            <span className="text-[#0b1c30] font-medium capitalize">
              {activeTab === 'violation' ? 'Security Intercept' : activeTab}
            </span>
          </div>

          {activeTab !== 'violation' && (
            <button
              onClick={() => setActiveTab('violation')}
              className="text-[11px] font-mono px-2 py-1 rounded bg-[#ffdad6] text-[#93000a] hover:bg-[#ffb4ab] transition-colors cursor-pointer flex items-center gap-1 border border-[#ba1a1a]/30"
            >
              <span className="material-symbols-outlined text-[14px]">warning</span>
              <span>Inspect Intercept #INC-901844</span>
            </button>
          )}
        </div>

        {/* View Switcher */}
        {activeTab === 'overview' && (
          <OverviewView
            agents={agents}
            mandates={mandates}
            transactions={transactions}
            onOpenProof={(tx) => setProofTarget(tx)}
            onOpenPanic={() => setIsPanicOpen(true)}
            onOpenCreateMandate={() => setIsCreateMandateOpen(true)}
            onNavigateTab={setActiveTab}
            panicSevered={panicSevered}
          />
        )}

        {activeTab === 'agents' && (
          <AgentsView
            agents={agents}
            onOpenRegisterModal={() => setIsRegisterAgentOpen(true)}
            onRevokeAgent={handleRevokeAgent}
            onRotateSignature={handleRotateSignature}
          />
        )}

        {activeTab === 'mandates' && (
          <MandatesView
            mandates={mandates}
            onOpenCreateMandate={() => setIsCreateMandateOpen(true)}
            onEditLimit={(m) => setEditLimitTarget(m)}
            onToggleRevoke={handleToggleRevokeMandate}
          />
        )}

        {activeTab === 'transactions' && <PaymentVerificationView />}

        {activeTab === 'security' && <SecurityAuditView />}

        {activeTab === 'violation' && (
          <SecurityViolationView
            onResolveViolation={handleResolveViolation}
            onNavigateTab={setActiveTab}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer />

      {/* Global Modals */}
      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        agents={agents}
        mandates={mandates}
        transactions={transactions}
        onSelectTab={setActiveTab}
        onOpenProof={(tx) => setProofTarget(tx)}
      />

      <PanicModal
        isOpen={isPanicOpen}
        onClose={() => setIsPanicOpen(false)}
        onConfirm={handleConfirmPanic}
      />

      <CreateMandateModal
        isOpen={isCreateMandateOpen}
        onClose={() => setIsCreateMandateOpen(false)}
        agents={agents}
        onSaveMandate={handleSaveMandate}
      />

      <RegisterAgentModal
        isOpen={isRegisterAgentOpen}
        onClose={() => setIsRegisterAgentOpen(false)}
        onRegisterAgent={handleRegisterAgent}
      />

      <EditLimitModal
        isOpen={!!editLimitTarget}
        onClose={() => setEditLimitTarget(null)}
        mandate={editLimitTarget}
        onSaveLimit={handleSaveLimit}
      />

      <ProofModal
        isOpen={!!proofTarget}
        onClose={() => setProofTarget(null)}
        txId={proofTarget?.id}
        agent={proofTarget?.agent}
        merchant={proofTarget?.merchant}
        amount={proofTarget?.amount}
        status={proofTarget?.decision === 'ALLOW' ? 'ALLOWED' : 'VERIFIED'}
      />
    </div>
  );
}
