export type ActiveTab = 'overview' | 'agents' | 'mandates' | 'transactions' | 'security' | 'violation';

export interface AgentNode {
  id: string;
  name: string;
  runtimeId: string;
  status: 'ACTIVE' | 'REVOKED' | 'IDLE';
  creator: string;
  creatorSub: string;
  cap: string;
  scopeSummary: string;
  heartbeat: string;
  heartbeatCode: string;
  authorizedAmount: number;
  requestedAmount: number;
  remainingHeadroom: number;
  policy: string;
  hash: string;
  mccAllowed: string[];
  expiryDate: string;
  velocityLimit: string;
  canSubDelegate: boolean;
  delegationTarget?: string;
  purpose: string;
}

export interface MandateItem {
  id: string;
  code: string;
  name: string;
  expiry: string;
  spent: number;
  cap: number;
  safeBuffer: string;
  isThresholdImminent?: boolean;
  boundAgent: string;
  subDelegationNote?: string;
  agentHash: string;
  permittedScopeTitle: string;
  mccCode: string;
  mccDetail: string;
  status: 'ACTIVE' | 'REVOKED';
}

export interface TransactionRecord {
  id: string;
  time: string;
  agent: string;
  agentColor: string;
  action: string;
  amount: string;
  decision: 'ALLOW' | 'VERIFY' | 'BLOCK';
  statusLabel: string;
  verificationType: 'proof' | 'violation';
  merchant: string;
  mcc: string;
  rawAmount: number;
  timestamp: string;
}

export interface AuditStep {
  stepNumber: number;
  title: string;
  badge: string;
  timestamp: string;
  description: string;
  detailLabel: string;
  detailValue: string;
  isTerminal?: boolean;
}
