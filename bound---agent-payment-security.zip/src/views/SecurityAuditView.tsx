import React, { useState } from 'react';
import { PROVENANCE_STEPS } from '../data/mockData';

export const SecurityAuditView: React.FC = () => {
  const [copiedCli, setCopiedCli] = useState(false);
  const [showCliModal, setShowCliModal] = useState(false);

  const cliCommand = 'bound verify --tx 901923 --pcr0 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

  const handleCopyCli = () => {
    navigator.clipboard?.writeText(cliCommand);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  const handleExportJson = () => {
    const auditData = {
      audit_event: 'BOUND_PROVENANCE_AUDIT',
      tx_id: 'tx_901923',
      merkle_root: '0x7f8a9310bc9401f8e100918a230198e09f44bca10018',
      block_height: 4192841,
      nitro_attestation: {
        pcr0: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        enclave_version: '2.4.19',
        quorum: '3/3 nodes validated',
      },
      provenance_steps: PROVENANCE_STEPS,
    };
    const blob = new Blob([JSON.stringify(auditData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bound-provenance-audit-901923.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-[#c6c6cd]/30">
        <div>
          <span className="font-mono text-[11px] text-[#76777d] uppercase tracking-wider block mb-1">
            Zero-Knowledge Hardware Verification
          </span>
          <h1 className="font-headline-xl text-[28px] sm:text-[32px] text-[#0b1c30] font-semibold tracking-tight">
            Security &amp; Provenance Audit
          </h1>
          <p className="font-body-md text-[14px] text-[#45464d] mt-1 max-w-2xl">
            Complete cryptographic audit trail for Transaction #tx_901923 (ABC Supermarket · ₹820).
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 self-start md:self-auto">
          <button
            onClick={() => setShowCliModal(true)}
            className="px-3.5 py-2 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1c30] text-[12px] font-medium transition-colors cursor-pointer flex items-center gap-1.5 border border-[#c6c6cd]/30"
          >
            <span className="material-symbols-outlined text-[16px]">terminal</span>
            <span>CLI Verify</span>
          </button>
          <button
            onClick={handleExportJson}
            className="px-4 py-2 rounded-lg bg-[#000000] text-[#ffffff] text-[12px] font-medium hover:opacity-90 transition-opacity cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <span className="material-symbols-outlined text-[16px]">download</span>
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Merkle Verification Path Status Card */}
      <div className="p-6 rounded-xl bg-[#ffffff] border border-[#c6c6cd]/30 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[#009668] text-[24px]">
              verified
            </span>
            <div>
              <h2 className="font-headline-md text-[18px] text-[#0b1c30] font-semibold">
                Merkle Verification Path
              </h2>
              <span className="font-mono text-[11px] text-[#009668] font-medium">
                STATUS: VERIFIED · 8 of 8 Invariants Deterministically Satisfied
              </span>
            </div>
          </div>
          <span className="font-mono text-[11px] px-2.5 py-1 rounded bg-[#eff4ff] text-[#0051d5] border border-[#c6c6cd]/30 font-semibold self-start sm:self-auto">
            BLOCK #4,192,841
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 font-mono text-[11px] text-[#45464d]">
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/25">
            <span className="text-[#76777d] block text-[10px] uppercase">Merkle Root:</span>
            <span className="font-medium text-[#0b1c30] break-all">
              0x7f8a9310bc9401f8e100918a230198e09f44bca1
            </span>
          </div>
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/25">
            <span className="text-[#76777d] block text-[10px] uppercase">Nitro PCR0 Hash:</span>
            <span className="font-medium text-[#0b1c30] break-all">
              e3b0c44298fc1c149afbf4c8996fb92427ae41e4...
            </span>
          </div>
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/25">
            <span className="text-[#76777d] block text-[10px] uppercase">Hardware Enclave:</span>
            <span className="font-medium text-[#009668]">AWS Nitro v2.4.19 (Isolated Ring-0)</span>
          </div>
        </div>
      </div>

      {/* Participating Entities */}
      <div className="p-6 rounded-xl bg-[#ffffff] border border-[#c6c6cd]/30 shadow-xs space-y-4">
        <h2 className="font-headline-md text-[18px] text-[#0b1c30] font-semibold">
          Participating Entities &amp; Attestation Keys
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-[11px]">
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/30 space-y-1">
            <span className="text-[#76777d] block text-[10px]">1. User Principal</span>
            <span className="font-semibold text-[#0b1c30]">Vault #492 (Human)</span>
            <span className="text-[#45464d] text-[10px] block truncate">
              pk:0x981a3d12bf087e
            </span>
          </div>
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/30 space-y-1">
            <span className="text-[#76777d] block text-[10px]">2. Mandate Assignee</span>
            <span className="font-semibold text-[#0b1c30]">Shopping Agent</span>
            <span className="text-[#45464d] text-[10px] block truncate">
              agt_01h8x9p3km
            </span>
          </div>
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/30 space-y-1">
            <span className="text-[#76777d] block text-[10px]">3. Execution Pipe</span>
            <span className="font-semibold text-[#0b1c30]">Payment Agent</span>
            <span className="text-[#45464d] text-[10px] block truncate">
              agt_09v4c1k9qa
            </span>
          </div>
          <div className="p-3.5 rounded-lg bg-[#eff4ff]/60 border border-[#c6c6cd]/30 space-y-1">
            <span className="text-[#76777d] block text-[10px]">4. Settlement Gateway</span>
            <span className="font-semibold text-[#0b1c30]">ABC Supermarket POS</span>
            <span className="text-[#45464d] text-[10px] block truncate">
              MID-ABC-IND-901
            </span>
          </div>
        </div>
      </div>

      {/* 8-Step Provenance Timeline */}
      <div className="p-6 rounded-xl bg-[#ffffff] border border-[#c6c6cd]/30 shadow-xs space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-headline-md text-[18px] text-[#0b1c30] font-semibold">
              8-Step Provenance Chain
            </h2>
            <p className="text-[12px] text-[#76777d] mt-0.5">
              Chronological cryptographic execution log committed directly to the verifiable ledger.
            </p>
          </div>
          <span className="font-mono text-[11px] text-[#009668] px-2 py-0.5 rounded bg-[#eff4ff] border border-[#c6c6cd]/30">
            TOTAL TIME: 4.348s
          </span>
        </div>

        <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#c6c6cd]/40">
          {PROVENANCE_STEPS.map((step) => (
            <div key={step.stepNumber} className="relative group">
              <span
                className={`absolute -left-[27px] top-1.5 w-3.5 h-3.5 rounded-full border-2 border-[#ffffff] ${
                  step.isTerminal ? 'bg-[#009668]' : 'bg-[#0051d5]'
                }`}
              ></span>

              <div className="p-4 rounded-xl bg-[#eff4ff]/60 border border-[#c6c6cd]/30 space-y-2 hover:border-[#0051d5]/40 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="flex items-center gap-2">
                    <span className="font-headline-sm text-[14px] font-semibold text-[#0b1c30]">
                      {step.title}
                    </span>
                    <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-[#ffffff] text-[#0051d5] border border-[#c6c6cd]/30 font-medium">
                      {step.badge}
                    </span>
                  </div>
                  <span className="font-mono text-[11px] text-[#76777d]">
                    {step.timestamp}
                  </span>
                </div>

                <p className="text-[13px] text-[#45464d] leading-relaxed">
                  {step.description}
                </p>

                <div className="pt-2 border-t border-[#c6c6cd]/25 flex items-center gap-2 font-mono text-[11px]">
                  <span className="text-[#76777d]">{step.detailLabel}</span>
                  <span className="text-[#0b1c30] font-medium break-all">
                    {step.detailValue}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CLI Verification Modal */}
      {showCliModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#131b2e]/60 p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-xl bg-[#ffffff] shadow-2xl p-6 space-y-4 border border-[#c6c6cd]/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#0051d5] text-[20px]">
                  terminal
                </span>
                <h3 className="font-headline-md text-[18px] text-[#0b1c30] font-semibold">
                  Independent CLI Verification
                </h3>
              </div>
              <button
                onClick={() => setShowCliModal(false)}
                className="text-[#45464d] hover:text-[#0b1c30] cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <p className="text-[12px] text-[#45464d]">
              Run this command in any terminal with the Bound CLI installed to verify the Nitro enclave PCR0 hash and Merkle leaf path offline.
            </p>

            <div className="p-3 rounded-lg bg-[#131b2e] text-[#f8f9ff] font-mono text-[11px] break-all leading-relaxed">
              {cliCommand}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#c6c6cd]/20">
              <button
                onClick={() => setShowCliModal(false)}
                className="px-3.5 py-2 rounded text-[12px] font-medium text-[#0b1c30] hover:bg-[#eff4ff] transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={handleCopyCli}
                className="px-4 py-2 rounded text-[12px] font-medium bg-[#000000] text-[#ffffff] hover:opacity-90 transition-opacity cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <span className="material-symbols-outlined text-[16px]">
                  {copiedCli ? 'check' : 'content_copy'}
                </span>
                <span>{copiedCli ? 'Copied Command' : 'Copy CLI Command'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
